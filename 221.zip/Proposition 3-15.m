// Proposition 3.15. The birational map to a smooth (1,1)-divisor

k<s> := QuadraticField(-3);
a := s/3;
T<u,v> := PolynomialRing(k,2);
S<y0,y1,y2,y3> := PolynomialRing(k,4);

// Use cubic monomials vanishing to order at least two at q = (0:0:0:1).
mon := [m : m in MonomialsOfDegree(S,3) | Degree(m,4) le 1];
P<x0,x1,x2,x3,x4> := ProjectiveSpace(k,4);
Q := Scheme(P,3*x2^2-4*x1*x3+x0*x4);
forms := [];
// For each projection, the cubics through the projected quartic should form a vector space of dimension three.
for e in [1,-1] do
    c := [u^3*v,u*v^3,v^4-u^4,u^2*v^2-e*a*u^4];
    M := Matrix(k,[
        [MonomialCoefficient(Evaluate(m,c),u^(12-j)*v^j)
         : j in [0..12]] : m in mon]);
    V := Nullspace(M);
    Dimension(V);
    rho := [x1,x3,x4-x0,x2-e*a*x0];
    Append(~forms,[
        &+[w[j]*Evaluate(mon[j],rho) : j in [1..#mon]]
        : w in Basis(V)]);
end for;

// Check that the image is a smooth (1,1)-divisor and that the map is birational.
P22<X1,Y1,Z1,X2,Y2,Z2> := ProductProjectiveSpace(k,[2,2]);
psi := map<Q -> P22 | forms[1] cat forms[2]>;
W := Image(psi);
DefiningPolynomials(W);
[Multidegree(P22,f) : f in DefiningPolynomials(W)];
IsNonsingular(W);
birational, inverse := IsInvertible(map<Q -> W | forms[1] cat forms[2]>);
birational;
